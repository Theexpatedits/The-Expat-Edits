# The Expat Edits

## Publish with GitHub Pages

1. Create a GitHub repository.
2. Upload every file in this folder.
3. Commit changes.
4. Go to Settings -> Pages.
5. Source: Deploy from a branch.
6. Branch: main / root.
7. Save.

Your website will be published in a minute or two.
